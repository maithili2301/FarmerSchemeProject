 package service;

import entities.BidderEntity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dao.BaseConnectionClass;
import dao.BidderDAO;
import dao.BidderDAOImplementation;

public class BidderServiceImplementation extends BaseConnectionClass implements BidderService {
     BidderDAO bidderDaoObj=new BidderDAOImplementation();
	@Override
	public void insertBidderService(BidderEntity bidderEntity) {
		bidderDaoObj.insertBidder(bidderEntity);
		
	}

	@Override
	public BidderEntity selectBidderService(int id) {
		
		return bidderDaoObj.selectBidder(id);
	}

	@Override
	public void updateBidderService(BidderEntity BidderEntity) {
		 bidderDaoObj.updateBidder(BidderEntity);
	}

	@Override
	public void deleteBidderService(int id) {
		// TODO Auto-generated method stub
		bidderDaoObj.deleteBidder(id);
		
	}

	@Override
	public void updateAmountBidderService(BidderEntity BidderrEntity, int bidder_id, int amt) {
		
			int n = 0;

			try {

				Statement statement = conn.createStatement();

				ResultSet result1 = statement
						.executeQuery("Select BIDDER_WALLET from BIDDER_DETAILS WHERE BIDDER_ID=" + bidder_id);
				while (result1.next()) {
					n = result1.getInt(1);
				}
				System.out.println("Original amt : " + n);
				int finalAmt = n - amt;
				PreparedStatement pst = conn.prepareStatement(
						"UPDATE BIDDER_DETAILS SET BIDDER_WALLET=" + finalAmt + " WHERE BIDDER_ID=" + bidder_id);

				System.out.println("PreparedStatement is created : " + pst);

				// 4. execute that statement // UR TABLENAME IS MYDEPT120
				pst.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	
	

	@Override
	public int maxIdBidderService() {
	
			System.out.println("In max id");
			int i=0;
			try {
			PreparedStatement pst = conn.prepareStatement("Select max(BIDDER_ID) as maxIdVal from BIDDER_DETAILS");

			ResultSet result = pst.executeQuery();
			if (result.next()) {
				System.out.println("in if ");
				i = result.getInt("maxIdVal");
				System.out.println(i);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return i;
		
	}

}
