package service;

import java.util.List;

import entities.CropDetailsEntity;

public interface CropService {
	public void insertCropService(CropDetailsEntity cropDetailsEntity);

	public CropDetailsEntity selectCropService(int id);
    public List<CropDetailsEntity> selectAllCropService();
    public List<CropDetailsEntity> selectAllCropNotSoldService();
	public void updateCropService(CropDetailsEntity cropDetailsEntity);
	public void updateCropSoldStatusService(int id);
	public int selectFarmerIdService(int id);
	public void deleteCropService(int id);
	public boolean soldOrNotService(int id);
}
