package service;

import entities.FarmerEntity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dao.FarmerDAO;
import dao.FarmerDAOImplementation;
import dao.BaseConnectionClass;

public class FarmerServiceImplementation extends BaseConnectionClass implements FarmerService {
     FarmerDAO farmerDaoObj=new FarmerDAOImplementation();
	@Override
	public void insertFarmerService(FarmerEntity farmerEntity) {
		
		farmerDaoObj.insertFarmer(farmerEntity);
	}

	@Override
	public void updateFarmerService(FarmerEntity farmerEntity) {
		farmerDaoObj.updateFarmer(farmerEntity);
		
	}

	@Override
	public void updateAmountFarmerService(FarmerEntity farmerEntity, int farmer_id, int amt) {
		
		
		
			int n = 0;

			try {

				Statement statement = conn.createStatement();

				ResultSet result1 = statement
						.executeQuery("Select  FARMER_WALLET from FARMERDETAILS3 WHERE FARMER_ID=" + farmer_id);
				while (result1.next()) {
					n = result1.getInt(1);
				}
				System.out.println("Original amt : " + n);
				int finalAmt = n + amt;
				PreparedStatement pst = conn.prepareStatement(
						"UPDATE FARMERDETAILS3 SET FARMER_WALLET=" + finalAmt + " WHERE FARMER_ID=" + farmer_id);
//					pst.setInt(1, (amt+farmerEntity.getAmount()));

				System.out.println("PreparedStatement is created : " + pst);

				// 4. execute that statement // UR TABLENAME IS MYDEPT120
				pst.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
	

	@Override
	public void deletFarmerService(String aadharCard) {
		farmerDaoObj.deleteFarmer(aadharCard);
		
	}

	@Override
	public FarmerEntity selectFarmerService(int id) {
		
		return farmerDaoObj.selectFarmer(id);
	}

	@Override
	public int maxIdService() {
		// TODO Auto-generated method stub
		
		
			// TODO Auto-generated method stub
			System.out.println("In max id");
			int i=0;
			try {
			PreparedStatement pst = conn.prepareStatement("Select max(FARMER_ID) as maxIdVal from FARMERDETAILS3");

			ResultSet result = pst.executeQuery();
			if (result.next()) {
				System.out.println("in if ");
				i = result.getInt("maxIdVal");
				System.out.println(i);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
			
		}
		
		
	}


