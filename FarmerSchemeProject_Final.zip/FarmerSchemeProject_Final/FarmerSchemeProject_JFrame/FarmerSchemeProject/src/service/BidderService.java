package service;

import entities.BidderEntity;

public interface BidderService {
	public void insertBidderService(BidderEntity bidderEntity);
	public BidderEntity selectBidderService(int id);
	public void updateBidderService(BidderEntity BidderEntity);
	public void deleteBidderService(int id);
	void updateAmountBidderService(BidderEntity BidderrEntity, int bidder_id, int amt);
	public int maxIdBidderService();
}
