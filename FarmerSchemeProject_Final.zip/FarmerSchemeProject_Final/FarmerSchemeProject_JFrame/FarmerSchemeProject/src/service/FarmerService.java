package service;

import entities.FarmerEntity;
import dao.FarmerDAO;

public interface FarmerService {
	public void insertFarmerService(FarmerEntity farmerEntity);
//	public void insertFarmer(FarmerEntity farmerEntity);
	
	public void updateFarmerService(FarmerEntity farmerEntity);
	public void updateAmountFarmerService(FarmerEntity farmerEntity,int farmer_id,int amt);
	public void deletFarmerService(String aadharCard);

	public FarmerEntity selectFarmerService(int id);
	public int maxIdService();
}
