import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.BidderDAO;
import dao.BidderDAOImplementation;
import dao.FarmerDAO;
import dao.FarmerDAOImplementation;
import entities.*;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

import service.*;

public class BidderRegistrationPage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BidderRegistrationPage frame = new BidderRegistrationPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BidderRegistrationPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1290, 742);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 1256, 695);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Bidder Registeration Form");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(573, 0, 239, 30);
		panel.add(lblNewLabel);
		
		JLabel lblPersonalDetails = new JLabel("Personal Details");
		lblPersonalDetails.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPersonalDetails.setBounds(605, 27, 134, 30);
		panel.add(lblPersonalDetails);
		
		JLabel lblNewLabel_1 = new JLabel("Full Name ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(482, 59, 114, 24);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Contact Number");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_1.setBounds(482, 94, 114, 24);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Email ID");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_2.setBounds(493, 128, 69, 24);
		panel.add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setBounds(651, 67, 265, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(651, 96, 265, 19);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(651, 125, 265, 19);
		panel.add(textField_2);
		
		JLabel lblAddressDetails = new JLabel("Address Details");
		lblAddressDetails.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddressDetails.setBounds(605, 155, 144, 30);
		panel.add(lblAddressDetails);
		
		JLabel lblNewLabel_1_3 = new JLabel("Address");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3.setBounds(493, 206, 69, 24);
		panel.add(lblNewLabel_1_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(651, 194, 265, 36);
		panel.add(textField_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("City");
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1.setBounds(503, 240, 69, 24);
		panel.add(lblNewLabel_1_3_1);
		
		JLabel lblNewLabel_1_3_2 = new JLabel("State");
		lblNewLabel_1_3_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_2.setBounds(493, 265, 69, 24);
		panel.add(lblNewLabel_1_3_2);
		
		JLabel lblNewLabel_1_3_3 = new JLabel("Pincode");
		lblNewLabel_1_3_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_3.setBounds(493, 299, 69, 24);
		panel.add(lblNewLabel_1_3_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(651, 240, 265, 19);
		panel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(651, 269, 265, 19);
		panel.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(651, 298, 265, 19);
		panel.add(textField_6);
		
		JLabel lblBankDetails = new JLabel("Bank Details");
		lblBankDetails.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblBankDetails.setBounds(605, 326, 144, 24);
		panel.add(lblBankDetails);
		
		JLabel lblNewLabel_1_3_1_1 = new JLabel("Account No");
		lblNewLabel_1_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_1.setBounds(503, 349, 103, 24);
		panel.add(lblNewLabel_1_3_1_1);
		
		JLabel lblNewLabel_1_3_1_2 = new JLabel("IFSC code");
		lblNewLabel_1_3_1_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2.setBounds(513, 380, 69, 24);
		panel.add(lblNewLabel_1_3_1_2);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(651, 352, 265, 19);
		panel.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(651, 383, 265, 19);
		panel.add(textField_8);
		
		JLabel lblNewLabel_1_3_1_2_1 = new JLabel("Aadhar Card");
		lblNewLabel_1_3_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2_1.setBounds(493, 441, 103, 24);
		panel.add(lblNewLabel_1_3_1_2_1);
		
		JLabel lblNewLabel_1_3_1_2_2 = new JLabel("Pan Card");
		lblNewLabel_1_3_1_2_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2_2.setBounds(513, 476, 69, 24);
		panel.add(lblNewLabel_1_3_1_2_2);
		
		JLabel lblDocuments = new JLabel("Documents");
		lblDocuments.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDocuments.setBounds(605, 411, 144, 19);
		panel.add(lblDocuments);
		
		JLabel lblNewLabel_1_3_1_2_2_1 = new JLabel("Password");
		lblNewLabel_1_3_1_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2_2_1.setBounds(503, 546, 69, 24);
		panel.add(lblNewLabel_1_3_1_2_2_1);
		
		JLabel lblNewLabel_1_3_1_2_2_2 = new JLabel("Confirm Password");
		lblNewLabel_1_3_1_2_2_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2_2_2.setBounds(468, 581, 134, 24);
		panel.add(lblNewLabel_1_3_1_2_2_2);
		
		

		JButton btnNewButton_1 = new JButton("Choose File");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					JFileChooser filechooser=new JFileChooser();
					int num=filechooser.showSaveDialog(null);
					String nameOfFile = null;
					 if (num == JFileChooser.APPROVE_OPTION) {
						 File file=filechooser.getSelectedFile();
						 nameOfFile=file.getName();
					 }
					 btnNewButton_1.setText(nameOfFile);
					
				}
			
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(651, 443, 265, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Choose File");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
					JFileChooser filechooser=new JFileChooser();
					int num=filechooser.showSaveDialog(null);
					String nameOfFile = null;
					 if (num == JFileChooser.APPROVE_OPTION) {
						 File file=filechooser.getSelectedFile();
						 nameOfFile=file.getName();
					 }
					 btnNewButton_1_1.setText(nameOfFile);
					
				}
			
		});
		btnNewButton_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1.setBounds(651, 478, 265, 23);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("Choose File");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
					JFileChooser filechooser=new JFileChooser();
					int num=filechooser.showSaveDialog(null);
					String nameOfFile = null;
					 if (num == JFileChooser.APPROVE_OPTION) {
						 File file=filechooser.getSelectedFile();
						 nameOfFile=file.getName();
					 }
					 btnNewButton_1_2.setText(nameOfFile);
					
				
			}
		});
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(651, 512, 265, 23);
		panel.add(btnNewButton_1_2);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				BidderDAO bidderDAOObject=new BidderDAOImplementation();
				BidderService bidderServiceObj=new BidderServiceImplementation();
				BidderEntity bidderEntity=new BidderEntity();
				bidderEntity.setBidderName(textField.getText());
				bidderEntity.setPhoneNumber(textField_1.getText());
				bidderEntity.setEmail(textField_2.getText());
				bidderEntity.setArea(textField_3.getText());
				bidderEntity.setCity(textField_4.getText());;
				bidderEntity.setState(textField_5.getText());
				bidderEntity.setPinCode(textField_6.getText());
				bidderEntity.setAccountNumber(textField_7.getText());
				bidderEntity.setIfscCode(textField_8.getText());
				bidderEntity.setAadharCard(btnNewButton_1.getText());
				bidderEntity.setTradingCertificate(btnNewButton_1_2.getText());
				bidderEntity.setPanCard(btnNewButton_1_1.getText());
				bidderEntity.setPassword(passwordField.getText());

				
				bidderServiceObj.insertBidderService(bidderEntity);
				
				
				System.out.println(bidderServiceObj.maxIdBidderService());
				 JOptionPane.showMessageDialog(null,"Welcome "+textField.getText()+" Your ID is "+bidderServiceObj.maxIdBidderService());
			
			}
		});
		btnNewButton.setBackground(new Color(154, 205, 50));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(493, 616, 112, 36);
		panel.add(btnNewButton);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnReset.setBackground(new Color(255, 0, 0));
		btnReset.setBounds(730, 616, 112, 36);
		panel.add(btnReset);
		
		JLabel lblNewLabel_1_3_1_2_2_3 = new JLabel("Trader Certificate");
		lblNewLabel_1_3_1_2_2_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_3_1_2_2_3.setBounds(482, 511, 123, 24);
		panel.add(lblNewLabel_1_3_1_2_2_3);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(651, 549, 265, 20);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(651, 580, 265, 20);
		panel.add(passwordField_1);
		
	}
}