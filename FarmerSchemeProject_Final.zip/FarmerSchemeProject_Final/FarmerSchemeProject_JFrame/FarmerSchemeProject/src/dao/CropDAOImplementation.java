package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.CropDetailsEntity;
import entities.FarmerEntity;

public class CropDAOImplementation extends BaseConnectionClass implements CropDAO {

	@Override
	public void insertCrop(CropDetailsEntity cropDetailsEntity) {

		try {
			PreparedStatement pst = conn.prepareStatement(
					"INSERT INTO CROP_DETAILS(CROP_NAME,FERTILIZER_TYPE,QUANTITY,SOIL_PH_CERTIFICATE,FARMER_ID,SOLD_OR_NOT) VALUES (?,?,?,?,?,?)");

			pst.setString(1, cropDetailsEntity.getCropName());
			pst.setString(2, cropDetailsEntity.getFertilizerType());
			pst.setString(3, cropDetailsEntity.getQuntity());
			pst.setString(4, cropDetailsEntity.getSoilpHCertificate());
			pst.setInt(5, cropDetailsEntity.getFarmer_ID());
			pst.setString(6, "Not Sold");
//		pst.setString(5, );
//		pst.setInt(5, );
//		pst.setInt(5, farmerEntiy.);
			int row = pst.executeUpdate();
			System.out.println("record added " + row);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	   pst.setString(5, cropDetailsEntity.);
//	   
//	   FarmerEntiy 

	}

	@Override
	public CropDetailsEntity selectCrop(int id) {
		CropDetailsEntity cropEntity = new CropDetailsEntity();
		try {

			Statement statement = conn.createStatement();

			ResultSet result1 = statement.executeQuery("Select  * from CROP_DETAILS WHERE CROP_ID =" + id);
			while (result1.next()) {

				cropEntity.setCropId(result1.getInt(1));
				cropEntity.setCropName(result1.getString(2));
				cropEntity.setFertilizerType(result1.getString(3));
				cropEntity.setQuntity(result1.getString(4));
				cropEntity.setSoilpHCertificate(result1.getString(5));
				cropEntity.setFarmer_ID(result1.getInt(6));

			}
			ResultSetMetaData rsmd = result1.getMetaData();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cropEntity;
	}

	public int selectFarmerId(int id) {
		CropDetailsEntity cropEntity = new CropDetailsEntity();
		int n = 0;
		try {

			Statement statement = conn.createStatement();

			ResultSet result1 = statement.executeQuery("Select  FARMER_ID from CROP_DETAILS WHERE CROP_ID =" + id);
			while (result1.next()) {

				n = result1.getInt(1);
//				cropEntity.setCropName(result1.getString(2));
//				cropEntity.setFertilizerType(result1.getString(3));
//				cropEntity.setQuntity(result1.getString(4));
//				cropEntity.setSoilpHCertificate(result1.getString(5));
//				cropEntity.setFarmer_ID(result1.getInt(6));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return n;
	}

	@Override
	public void updateCrop(CropDetailsEntity cropDetailsEntity) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCrop(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<CropDetailsEntity> selectAllCrop() {
		List<CropDetailsEntity> cropList = new ArrayList<CropDetailsEntity>();
		try {
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery("select * from CROP_DETAILS");
			while (result.next()) {
				CropDetailsEntity cropEntity = new CropDetailsEntity();
				cropEntity.setCropId(result.getInt(1));
				cropEntity.setCropName(result.getString(2));
				cropEntity.setFertilizerType(result.getString(3));
				cropEntity.setQuntity(result.getString(4));
				cropEntity.setSoilpHCertificate(result.getString(5));
				cropEntity.setFarmer_ID(result.getInt(6));
				cropList.add(cropEntity);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cropList;
	}

	

	

	

}
