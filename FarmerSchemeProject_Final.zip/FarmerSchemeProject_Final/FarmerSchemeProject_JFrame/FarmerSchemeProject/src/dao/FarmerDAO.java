package dao;

import entities.FarmerEntity;

public interface FarmerDAO { //POJI as per POJO
	public void insertFarmer(FarmerEntity farmerEntity);
//	public void insertFarmer(FarmerEntity farmerEntity);
	
	public void updateFarmer(FarmerEntity farmerEntity);
//	public void updateAmountFarmer(FarmerEntity farmerEntity,int farmer_id,int amt);
	public void deleteFarmer(String aadharCard);

	public FarmerEntity selectFarmer(int id);
//	public int maxId();
	
  
}